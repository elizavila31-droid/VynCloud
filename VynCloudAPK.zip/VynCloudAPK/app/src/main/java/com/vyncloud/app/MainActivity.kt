package com.vyncloud.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.compose.ui.platform.LocalContext

private val Fondo = Color(0xFF070A12)
private val Panel = Color(0xFF101725)
private val Azul = Color(0xFF21C8FF)
private val Gris = Color(0xFF91A0B7)

data class Juego(val nombre: String, val categoria: String, val iniciales: String, val c1: Color, val c2: Color)
private val juegos = listOf(
    Juego("GTA V", "Acción", "GTA V", Color(0xFF102A3C), Color(0xFF176B8A)),
    Juego("Minecraft", "Supervivencia", "MINE\nCRAFT", Color(0xFF193B2A), Color(0xFF4C8A45)),
    Juego("Fortnite", "Acción", "FORT\nNITE", Color(0xFF302047), Color(0xFF7255C7)),
    Juego("Roblox", "Multijugador", "ROBLOX", Color(0xFF202B3D), Color(0xFF53647C)),
    Juego("Forza Horizon", "Carreras", "FORZA", Color(0xFF153849), Color(0xFF1B9BB2)),
    Juego("Red Dead Redemption 2", "Aventura", "RDR 2", Color(0xFF3A1D25), Color(0xFF9D463B)),
    Juego("EA Sports FC", "Deportes", "EA FC", Color(0xFF26351B), Color(0xFF879E39)),
    Juego("Cyberpunk 2077", "RPG", "CYBER\nPUNK", Color(0xFF382A12), Color(0xFFE2AD32))
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VynCloud() }
    }
}

@Composable
fun VynCloud() {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Todos") }
    var tab by remember { mutableStateOf("Inicio") }
    val categories = listOf("Todos", "Acción", "Aventura", "Carreras", "Deportes", "RPG", "Supervivencia", "Multijugador")
    val filtered = juegos.filter { (category == "Todos" || it.categoria == category) && it.nombre.contains(query, true) }

    MaterialTheme(colorScheme = darkColorScheme(primary = Azul, background = Fondo, surface = Panel)) {
        Scaffold(containerColor = Fondo, bottomBar = {
            NavigationBar(containerColor = Color(0xFF0B111D)) {
                listOf(Triple("Inicio", Icons.Default.Home, "Inicio"), Triple("Juegos", Icons.Default.SportsEsports, "Juegos"), Triple("Perfil", Icons.Default.Person, "Perfil")).forEach { (label, icon, destination) ->
                    NavigationBarItem(selected = tab == destination, onClick = { tab = destination }, icon = { Icon(icon, contentDescription = label) }, label = { Text(label) }, colors = NavigationBarItemDefaults.colors(selectedIconColor = Azul, selectedTextColor = Azul, indicatorColor = Color(0xFF15364A), unselectedIconColor = Gris, unselectedTextColor = Gris))
                }
            }
        }) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).background(Fondo)) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 17.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Cloud, null, tint = Azul, modifier = Modifier.size(30.dp)); Spacer(Modifier.width(7.dp))
                        Text("Vyn", color = Azul, fontSize = 25.sp, fontWeight = FontWeight.Black); Text("Cloud", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                    }
                    Text("● DEMO", color = Color(0xFF5BE3A1), fontSize = 11.sp)
                }
                if (tab == "Perfil") {
                    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Icon(Icons.Default.Person, null, tint = Azul, modifier = Modifier.size(60.dp)); Text("Perfil de jugador", color = Color.White, fontSize = 24.sp); Text("Las cuentas llegarán después.", color = Gris)
                    }
                } else {
                    Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp).clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0xFF123B5A), Color(0xFF10182A), Fondo))).padding(21.dp)) {
                        Text("JUEGA SIN LÍMITES", color = Azul, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Spacer(Modifier.height(10.dp)); Text("Tu mundo.\nTu partida.", color = Color.White, fontSize = 34.sp, lineHeight = 38.sp, fontWeight = FontWeight.Black)
                        Spacer(Modifier.height(8.dp)); Text("Descubre tu próxima aventura.", color = Gris, fontSize = 14.sp)
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 15.dp).clip(RoundedCornerShape(13.dp)).background(Panel).padding(horizontal = 14.dp, vertical = 15.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Search, null, tint = Gris); Spacer(Modifier.width(10.dp))
                        BasicTextField(value = query, onValueChange = { query = it }, singleLine = true, textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 15.sp), decorationBox = { inner -> if (query.isEmpty()) Text("Buscar juegos...", color = Gris); inner() }, modifier = Modifier.fillMaxWidth())
                    }
                    Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(9.dp)) {
                        Spacer(Modifier.width(7.dp))
                        categories.forEach { item ->
                            val active = category == item
                            Box(Modifier.clip(RoundedCornerShape(50)).background(if (active) Azul else Panel).clickable { category = item }.padding(horizontal = 17.dp, vertical = 11.dp)) {
                                Text(item, color = if (active) Fondo else Gris, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                        Spacer(Modifier.width(7.dp))
                    }
                    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(if (tab == "Juegos") "Todos los juegos" else "Biblioteca", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold); Text("${filtered.size} juegos", color = Gris, fontSize = 12.sp)
                    }
                    LazyVerticalGrid(columns = GridCells.Fixed(2), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        items(filtered, key = { it.nombre }) { game -> GameCard(game) }
                    }
                }
            }
        }
    }
}

@Composable
fun GameCard(game: Juego) {
    val context = LocalContext.current
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(15.dp)).background(Panel).padding(10.dp)) {
        // Icono cuadrado 1:1
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(11.dp)).background(Brush.linearGradient(listOf(game.c1, game.c2))), contentAlignment = Alignment.Center) {
            Text(game.iniciales, color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black, lineHeight = 25.sp)
        }
        Spacer(Modifier.height(10.dp)); Text(game.nombre, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Spacer(Modifier.height(4.dp)); Text(game.categoria, color = Gris, fontSize = 11.sp); Spacer(Modifier.height(11.dp))
        Button(onClick = { Toast.makeText(context, "${game.nombre}: falta conectar el servidor de streaming.", Toast.LENGTH_LONG).show() }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(9.dp), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF12364D), contentColor = Azul), contentPadding = PaddingValues(vertical = 9.dp)) { Text("JUGAR", fontWeight = FontWeight.Bold, fontSize = 12.sp) }
    }
}
