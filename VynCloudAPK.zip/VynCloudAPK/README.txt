VYNCLOUD ANDROID APK - PROTOTIPO NATIVO

Este proyecto Kotlin + Jetpack Compose incluye:
- UI nativa Android
- menú inferior
- categorías horizontales desplazables
- buscador
- tarjetas de juego con iconos 1:1

IMPORTANTE:
- Los iconos son marcadores visuales, no portadas oficiales.
- Los botones JUGAR son de demostración; no existe todavía servidor de streaming.
- El APK se compila mediante GitHub Actions con el workflow .github/workflows/build.yml.

Para obtener el APK desde un teléfono:
1. Crea un repositorio en GitHub llamado VynCloud.
2. Sube todos los archivos y carpetas de este proyecto al repositorio (incluida la carpeta oculta .github).
3. Abre la pestaña Actions del repositorio.
4. Selecciona Build VynCloud APK y pulsa Run workflow, o espera a que termine el flujo tras subir a main.
5. Abre la ejecución completada y descarga el artefacto VynCloud-debug-apk.
6. Extrae el ZIP descargado y abre app-debug.apk en Android para instalarlo.
